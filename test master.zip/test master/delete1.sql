DELETE FROM books_subjects WHERE subject=9;

DELETE FROM subjects WHERE name='History';