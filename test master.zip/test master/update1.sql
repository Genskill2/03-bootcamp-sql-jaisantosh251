UPDATE publisher
SET name='Prentice Hall'
WHERE id=1;